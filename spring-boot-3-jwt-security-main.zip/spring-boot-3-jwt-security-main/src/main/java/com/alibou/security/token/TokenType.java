package com.alibou.security.token;

public enum TokenType {
  BEARER
}
